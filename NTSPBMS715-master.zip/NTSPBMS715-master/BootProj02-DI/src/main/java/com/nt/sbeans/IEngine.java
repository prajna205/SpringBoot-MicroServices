//IEngine.java (Common interface)
package com.nt.sbeans;

public interface IEngine {
    public void  start();
    public  void stop();
}
