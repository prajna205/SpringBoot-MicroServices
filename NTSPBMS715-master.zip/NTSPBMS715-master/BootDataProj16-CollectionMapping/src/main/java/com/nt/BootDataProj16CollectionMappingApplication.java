package com.nt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootDataProj16CollectionMappingApplication {

	public static void main(String[] args) {
		SpringApplication.run(BootDataProj16CollectionMappingApplication.class, args);
	}

}
