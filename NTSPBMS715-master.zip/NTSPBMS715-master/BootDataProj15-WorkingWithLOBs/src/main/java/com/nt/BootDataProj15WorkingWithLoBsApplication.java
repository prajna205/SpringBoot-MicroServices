package com.nt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootDataProj15WorkingWithLoBsApplication {

	public static void main(String[] args) {
		SpringApplication.run(BootDataProj15WorkingWithLoBsApplication.class, args);
	}

}
