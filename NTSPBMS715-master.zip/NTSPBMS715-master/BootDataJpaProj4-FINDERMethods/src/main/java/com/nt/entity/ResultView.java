//ResultView.java
package com.nt.entity;

public interface ResultView {
   public int  getAid();
   public  String getAname();
}
