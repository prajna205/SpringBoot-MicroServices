package com.nt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootDataJpaProj7QueryMethodsApplication {

	public static void main(String[] args) {
		SpringApplication.run(BootDataJpaProj7QueryMethodsApplication.class, args);
	}

}
