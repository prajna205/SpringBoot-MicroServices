package com.nt.view;

public interface ResultView2 extends View {
   public    String getCategory();
   //public  long getMobileNo();
}
