package com.nt.view;

public interface ResultView1 extends View {
   public    int getAid();
   public  String getAname();
}
