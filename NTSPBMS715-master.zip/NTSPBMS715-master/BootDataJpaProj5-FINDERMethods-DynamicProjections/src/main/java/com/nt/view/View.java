package com.nt.view;

public interface View {

}
