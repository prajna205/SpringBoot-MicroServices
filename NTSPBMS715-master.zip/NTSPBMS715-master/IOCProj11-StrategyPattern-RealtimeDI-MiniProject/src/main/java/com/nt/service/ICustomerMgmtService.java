package com.nt.service;

import com.nt.dto.CustomerDTO;

public interface ICustomerMgmtService {
     public  String registerCustomer(CustomerDTO dto)throws Exception;
}
