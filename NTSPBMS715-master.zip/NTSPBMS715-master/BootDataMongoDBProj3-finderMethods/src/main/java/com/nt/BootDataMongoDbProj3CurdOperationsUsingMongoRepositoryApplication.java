package com.nt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootDataMongoDbProj3CurdOperationsUsingMongoRepositoryApplication {

	public static void main(String[] args) {
		SpringApplication.run(BootDataMongoDbProj3CurdOperationsUsingMongoRepositoryApplication.class, args);
	}

}
