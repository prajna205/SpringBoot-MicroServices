package com.nt.core;

public interface Arithemetic {
	public   int add(int a,int b);

}
