//IBankService.java
package com.nt.service;

public interface IBankService {
   public  String transferMoney(long srcAcno, long destAcno,double amount);
}
