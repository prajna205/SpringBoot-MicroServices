package com.nt.service;

import com.nt.document.PlayerInfo;

public interface IPlayerMgmtService {
    public   String registerPlayer(PlayerInfo info);
}
