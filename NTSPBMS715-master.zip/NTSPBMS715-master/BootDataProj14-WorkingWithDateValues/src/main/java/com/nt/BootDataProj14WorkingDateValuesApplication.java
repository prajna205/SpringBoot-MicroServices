package com.nt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootDataProj14WorkingDateValuesApplication {

	public static void main(String[] args) {
		SpringApplication.run(BootDataProj14WorkingDateValuesApplication.class, args);
	}

}
