//Company.java
package com.nt.sbeans;

import lombok.Data;

@Data
public class Company {
	private  Integer id;
	private  String  name;
	private  String addrs;
	private  String  size;
	

}
